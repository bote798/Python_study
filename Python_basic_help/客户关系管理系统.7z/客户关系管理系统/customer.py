# -*- coding: UTF-8 -*-
# @Project : __init__.py 
# @File    : customer.py
# @Author  : bote798
# @Date    : 2024/5/8 12:53 
# @IDE     : PyCharm

from __init__ import is_valid_phone_number


class Customer:
    def __init__(self, company, address, scale, contacts, job, telephone, annual_sale):
        self.company = company
        self.address = address
        self.scale = scale
        self.contacts = contacts
        self.job = job
        self.telephone = telephone
        self.annual_sale = annual_sale

    def return_info(self):
        return {
            "公司名称": self.company,
            "公司地址": self.address,
            "公司规模": self.scale,
            "联系人": self.contacts,
            "职位": self.job,
            "联系电话": self.telephone,
            "年销售额": self.annual_sale
        }


class Function:
    @staticmethod
    def add_customer():
        print("请添加客户信息")
        company = input("公司名称:\n")
        address = input("公司地址:\n")
        scale = input("公司规模:\n")
        contact = input("联系人:\n")
        job = input("职位:\n")
        tel = input("联系电话:\n")
        while is_valid_phone_number(tel) is False:
            tel = input("电话号码格式错误，请重新输入:\n")
        annual_sale = input("年销售额:\n")
        customers.append(Customer(company, address, scale, contact, job, tel, annual_sale))
        # 测试
        # print(customers[4].return_info())
        print("添加成功")

    @staticmethod
    def search_customer():
        print("查询客户信息")
        print("1. 查询所有客户信息")
        print("2. 查询指定客户信息")
        choice = input("请输入查询方式:\n")
        if choice == "1":
            for customer in customers:
                print(customer.return_info())
        elif choice == "2":
            company = input("请输入公司名称:\n")
            for customer in customers:
                if customer.company == company:
                    print(customer.return_info())

    @staticmethod
    def modify_customer():
        print("修改客户信息")
        company = input("请输入公司名称:\n")
        for customer in customers:
            if customer.company == company:
                print("找到该客户信息，请修改\n")
                customer.company = input("公司名称:\n")
                customer.address = input("公司地址:\n")
                customer.scale = input("公司规模:\n")
                customer.contacts = input("联系人:\n")
                customer.job = input("职位:\n")
                customer.telephone = input("联系电话:\n")
                while is_valid_phone_number(customer.telephone) is False:
                    customer.telephone = input("电话号码格式错误，请重新输入:\n")
                customer.annual_sale = input("年销售额:\n")
                print("修改成功")

    @staticmethod
    def delete_customer():
        print("删除客户信息")
        company = input("请输入需要修改的公司名称:\n")
        for customer in customers:
            if customer.company == company:
                customers.remove(customer)
                print("删除成功")


customers = [
    Customer("公司A", "地址A", "100人", "张三", "经理", "1234567890", "10000000"),
    Customer("公司B", "地址B", "50人", "李四", "经理", "9876543210", "5000000"),
    Customer("公司C", "地址C", "200人", "王五", "经理", "111111111", "2000000"),
    Customer("公司D", "地址D", "300人", "赵六", "经理", "222222222", "3000000"),
]

if __name__ == '__main__':
    pass
