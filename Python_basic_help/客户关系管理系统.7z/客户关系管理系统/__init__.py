# -*- coding: UTF-8 -*-
# @Project : __init__.py 
# @File    : __init__.py.py
# @Author  : bote798
# @Date    : 2024/5/8 12:51 
# @IDE     : PyCharm
import re


def is_valid_phone_number(phone_number):
    tel_pattern = r'^1[3-9]\d{9}$'
    # 正则表达式匹配手机号
    # is not None 表示匹配成功
    return re.match(tel_pattern, str(phone_number)) is not None
