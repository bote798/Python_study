# -*- coding: UTF-8 -*-
# @Project : __init__.py 
# @File    : user.py
# @Author  : bote798
# @Date    : 2024/5/8 13:00 
# @IDE     : PyCharm

class User:
    def __init__(self, username, password, type_user):
        self.username = username
        self.password = password
        self.type_user = type_user

    def return_info(self):
        return {
            "username": self.username,
            "password": self.password,
            "type_user": self.type_user
        }


users = [
    User("admin", "1234567", "admin"),
    User("user1", "1234568", "user"),
    User("user2", "1234569", "user")
]


if __name__ == '__main__':
    pass

