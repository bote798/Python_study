# -*- coding: UTF-8 -*-
# @Project : __init__.py 
# @File    : main.py
# @Author  : bote798
# @Date    : 2024/5/8 13:01 
# @IDE     : PyCharm
from Tools.demo.ss1 import center

import user
import customer
import re


def login():
    username = input("请输入用户名:\n")
    password = input("请输入密码:\n")
    for i in user.users:
        if i.username == username and i.password == password:
            print("登录成功！")
            # 菜单
            menu()
            break
    else:
        print("用户名或密码错误！")
        login()


# 菜单
def menu():
    while True:
        print('-' * 15, center("客户关系管理系统", 20), '-' * 15)
        print("1. 添加客户信息")
        print("2. 查看客户信息")
        print("3. 修改客户信息")
        print("4. 删除客户信息")
        print("5. 退出系统信息")
        print('-' * 57)
        choice = input("请输入您的选择:\n")
        if choice == "1":
            customer.Function.add_customer()
        elif choice == "2":
            customer.Function.search_customer()
        elif choice == "3":
            customer.Function.modify_customer()
        elif choice == "4":
            customer.Function.delete_customer()
        elif choice == "5":
            print("感谢使用客户关系管理系统，再见！")
            break
        else:
            print("输入有误，请重新输入！")


if __name__ == '__main__':
    login()
